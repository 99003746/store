#include<stdio.h>

#include "bitmask.h"
#include "mystring.h"
#include "myutils.h"



int main()
{
    factorial(5);
   pal_indrome(111);
    is_prime(5);
   
   //st_rcat("Hi","How are you");
   //string_copy("Nitin","Shetty");
   //string_comp("Nitin","Nitin");
   //str_len("Hello");
   
     flip(10,1);
     set(10,1);
    reset(10,1);
  
}
