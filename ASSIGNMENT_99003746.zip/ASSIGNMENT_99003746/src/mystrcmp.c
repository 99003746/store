#include "string.h"


char string_comp(char* str1,char* str2)
{

    

    if(strcmp(str1, str2)==0)
    {
        printf("\n Both the strings are same");
    }

    else
    {
        printf("\n Both the strings are different");
    }

   
    return 0;
}
