#include "string.h"



char st_rcat(char* str1,char* str2)
{
  
   strcat(str1, str2);

  
   printf("after concatenation: %s", str1);
 
   return 0;
   
}