#include "string.h"


int str_len(char* str1)
 {
   // char str1[20];
    

    
    printf("Length of the string: %d" , strlen(str1));
    return 0;
}