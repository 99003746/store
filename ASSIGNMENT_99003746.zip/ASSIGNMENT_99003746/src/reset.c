#include "bitmask.h"

int reset(int number,int key)
{
    printf("\n%d",(number&(~(1 < (key-1)))));
   // return(number&(~(1 < (key-1))));
}