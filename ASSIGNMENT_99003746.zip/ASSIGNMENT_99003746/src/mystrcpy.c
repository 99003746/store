#include "string.h"


char string_copy(char* a, char* b)
{
  //char a[15];
  //char b[15];
  printf("Before copying\n");
  printf("String 1: %s \n", a);
  printf("String 2: %s \n\n",b);
  
  strcpy(a,b);                         
  printf("After copying\n");
  printf("String 1: %s \n", a);
  printf("String 2: %s \n", b);

  return 0;
}