#include"bitmask.h"

int set(int number,int bit)
{
    printf("\n%d",(1 << bit) | number);
    //return((1 << bit) | number);
}