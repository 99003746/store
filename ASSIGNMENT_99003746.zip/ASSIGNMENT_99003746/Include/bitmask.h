#include<stdio.h>

int flip();
int set(int number,int bit);
int reset(int number,int key);
