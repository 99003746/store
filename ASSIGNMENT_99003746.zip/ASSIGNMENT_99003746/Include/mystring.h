#ifndef ADD1_H
#define ADD1_H

char st_rcat(char* str1,char* str2);
char string_copy(char* a, char* b);
char string_comp(char* str1,char* str2);
int str_len(char* str1);
#endif