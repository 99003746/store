#ifndef ADD_H
#define ADD_H

int factorial(int num);

int is_prime(int n); 

int pal_indrome(int n);
#endif
